const callTranslationApi = (() => {
    const _API_KEY = "YOUR API KEY";
    async function getTranslation(text, lang) {
        let res = await axios.post(
            `https://translation.googleapis.com/language/translate/v2?key=${_API_KEY}`, //https://translation.googleapis.com/language/translate/v2?key=${_API_KEY} this is the translation api
            { q: text, target: lang }
        );
        let translation = res.data.data.translations[0].translatedText;
        return translation;
    }
    return Object.assign({}, {getTranslation});
})();

const displayTranslation = (() => {
    let _translateButton = document.querySelector('.menu>button');
    _translateButton.addEventListener('click', async (e) => {
        e.preventDefault();
        const {getTranslation} = callTranslationApi;
        const select = document.getElementById('lang');
        const lang = select.options[select.selectedIndex].value;
        const input = document.querySelector('#input').value;
        const textarea = document.getElementById('translation');
        const translatedText = await getTranslation(input, lang);
        textarea.textContent = translatedText;
    });
    return {};
})();